# SmartRubleAI Article v3.1

Откройте Word или PDF — краткая статья на четырёх страницах. Основной текст и таблица TNR 14, интервал 1,5; русский и английский блоки, короткие аннотации.

В article-evidence-v31/TECHNICAL_APPENDIX.md — подробная методика и таблицы. В VERIFICATION.json — проверка запуска без Git и отдельного пересчёта CSV. В seed_dispersion.csv — разброс всех моделей, в latency_summary.json — единая методика и итог времени.

Исправления: запуск без main/.git, все типы ошибок среди автоматических решений, концентрация 24 из 33 опасных одобрений в одном разбиении, согласованное описание времени, двуязычный текст и российские научные источники.

Порядок воспроизведения из распакованного ZIP:
1. Открыть PowerShell в repository.
2. uv venv --python 3.14 .venv
3. uv pip install --python .venv\Scripts\python.exe -r requirements-article-lock.txt
4. .venv\Scripts\python.exe -X utf8 scripts\article_study.py
5. .venv\Scripts\python.exe -X utf8 scripts\article_package.py
6. .venv\Scripts\python.exe -m unittest discover -s tests -p test_article_study.py -v

Результаты — ../outputs/article-evidence-v31. Для редактирования Word дополнительно python-docx==1.2.0, затем scripts/build_article_v31.py. Все данные синтетические; показатели не оценивают риск реальных платежей. Первоисточник требований конференции нужно сверить перед подачей; параметры, взятые из рецензии, зафиксированы в DOCUMENT_CHECK.json.
