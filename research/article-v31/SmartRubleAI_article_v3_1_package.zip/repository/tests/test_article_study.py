"""Metric and leakage invariants for the article research, independent of model scores."""
import sys,json,tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from article_study import metrics, split_three, regional_rows, select_policies, source_version

class ArticleStudyTests(unittest.TestCase):
    def test_zip_version_uses_manifest_without_calling_git(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'SOURCE_VERSION.json').write_text(json.dumps({'base_commit':'declared-base'}),encoding='utf-8')
            with patch('article_study.subprocess.check_output',side_effect=AssertionError('Git must not run for ZIP')):
                self.assertEqual(source_version(root),{'base_commit':'declared-base','version_source':'source_manifest'})
    def test_missing_version_is_explicit_not_fabricated(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(source_version(Path(folder)),{'base_commit':None,'version_source':'unavailable'})
    def test_distinguishes_three_financial_error_types(self):
        rows=[('a','other','a'),('b','sports','b'),('c','uniform_top','c'),('d','other','d')]
        predictions=[('sports',.9),('uniform_top',.9),('other',.9),('other',.4)]
        m=metrics(rows,predictions)
        self.assertEqual((m['dangerous'],m['wrong_category'],m['wrong_reject']),(1,1,1))
        self.assertEqual(m['dangerous_rate'],.5)
        self.assertEqual(m['coverage'],.75)
        self.assertEqual(m['selective_error'],1)
    def test_base_names_are_disjoint_and_exhaustive(self):
        rows=regional_rows(0)
        chunks,parts=split_three(rows,0)
        self.assertTrue(all(len(chunk)>0 for chunk in chunks))
        self.assertFalse(set(parts[0])&set(parts[1]))
        self.assertFalse(set(parts[1])&set(parts[2]))
        self.assertFalse(set(parts[0])&set(parts[2]))
        self.assertEqual(sum(map(len,chunks)),len(rows))
    def test_constraints_can_abstain_from_unsafe_decisions(self):
        rows=[('a','other','a'),('b','sports','b')]
        policies=select_policies(rows,[('sports',1.),('other',1.)])
        a,r=policies['validation_constrained']
        m=metrics(rows,[('sports',1.),('other',1.)],a,r)
        self.assertEqual(m['coverage'],0)
        self.assertIsNone(m['selective_error'])

if __name__=='__main__': unittest.main()
