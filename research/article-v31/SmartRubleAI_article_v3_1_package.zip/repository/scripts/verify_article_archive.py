"""Verify independent counts and reproduce an extracted source ZIP without .git."""
from pathlib import Path
import csv,hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT.parent
E=PARENT/'outputs'/'article-evidence-v31'

def main():
 r=json.loads((E/'results.json').read_text(encoding='utf-8'))
 groups={}
 with (E/'predictions.csv').open(encoding='utf-8-sig') as f:
  for x in csv.DictReader(f,delimiter=';'):
   key=(x['dataset'],int(x['seed']),x['model']);groups.setdefault(key,[]).append(x)
 checked=0
 for row in r['results']:
  counts=dict(n=0,n_other=0,n_allowed=0,correct=0,approved=0,rejected=0,review=0,dangerous=0,wrong_category=0,wrong_reject=0)
  for x in groups[(row['dataset'],row['seed'],row['model'])]:
   y,p,c=x['true'],x['predicted'],float(x['score'])
   d='REVIEW'
   if p!='abstain':
    if p=='other' and c>=row['rejection']: d='REJECT'
    elif p!='other' and c>=row['approval']:d='APPROVE'
   counts['n']+=1;counts['n_other']+=y=='other';counts['n_allowed']+=y!='other';counts['correct']+=y==p
   counts[{'APPROVE':'approved','REJECT':'rejected','REVIEW':'review'}[d]]+=1
   counts['dangerous']+=y=='other' and d=='APPROVE'
   counts['wrong_category']+=y!='other' and y!=p and d=='APPROVE'
   counts['wrong_reject']+=y!='other' and d=='REJECT'
  assert all(counts[k]==row[k] for k in counts),(row,counts)
  checked+=1
 work=PARENT/'work'/'zip-check-v31';work.mkdir(parents=True,exist_ok=True)
 archive=work/'source-test.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for folder in ('src','scripts'):
   for p in (ROOT/folder).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:z.write(p,Path('repository')/p.relative_to(ROOT))
  z.write(ROOT/'SOURCE_VERSION.json','repository/SOURCE_VERSION.json')
 with zipfile.ZipFile(archive) as z:z.extractall(work/'extracted')
 extracted=work/'extracted'/'repository'
 assert not (extracted/'.git').exists()
 subprocess.run([sys.executable,'-X','utf8','scripts/article_study.py','--output',str(work/'rerun-evidence')],cwd=extracted,check=True)
 rerun=json.loads((work/'rerun-evidence'/'results.json').read_text(encoding='utf-8'))
 for key in ('protocol','legacy','workflow','results','splits','ambiguity'):
  assert r[key]==rerun[key],key
 assert rerun['environment']['version_source']=='source_manifest'
 report={'status':'PASS','policy_rows_recounted':checked,'prediction_rows':sum(map(len,groups.values())),
  'extracted_zip_run':'PASS','git_directory_present':False,'version_source':rerun['environment']['version_source'],
  'base_commit':rerun['environment']['base_commit'],
  'equal_fields':['protocol','legacy','workflow','results','splits','ambiguity'],
  'excluded_from_equality':['latency','environment.elapsed_seconds','environment.script_sha256'],
  'meaning':'Independent reexecution of source extracted from ZIP on this laptop in the pinned virtual environment; not an external laboratory replication'}
 (E/'VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
