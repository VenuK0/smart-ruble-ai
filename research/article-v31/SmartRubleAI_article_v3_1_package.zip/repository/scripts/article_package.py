"""Summaries and publication figures derived mechanically from article_study outputs."""
from pathlib import Path
import argparse,csv, hashlib, json, statistics, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'outputs'/'article-evidence-v31'
NAMES={'rules':'Правила по токенам','current_char':'TF-IDF C=8','regularized_char':'TF-IDF C=2','hybrid':'Символы и слова'}
DATA={'original':'Исходный предметный набор','regional':'Школьная и спортивная форма'}
COUNTS=['n','n_other','n_allowed','correct','approved','rejected','review','dangerous','wrong_category','wrong_reject']

def aggregate(rows):
    c={k:sum(x[k] for x in rows) for k in COUNTS}
    c.update(auto_errors=c['dangerous']+c['wrong_category']+c['wrong_reject'],accuracy=c['correct']/c['n'],coverage=(c['approved']+c['rejected'])/c['n'],
       dangerous_rate=c['dangerous']/c['n_other'],
       selective_error=(c['dangerous']+c['wrong_category']+c['wrong_reject'])/(c['approved']+c['rejected']) if c['approved']+c['rejected'] else None,
       min_coverage=min(x['coverage'] for x in rows),max_coverage=max(x['coverage'] for x in rows),
       mean_validation_coverage=statistics.mean(x['validation_coverage'] for x in rows) if 'validation_coverage' in rows[0] else None)
    return c

def pct(x): return f'{100*x:.2f}'.replace('.',',')+'%' if x is not None else '—'

def main():
 global OUT
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--evidence',type=Path,default=OUT)
 OUT=parser.parse_args().evidence.resolve()
 r=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
 summary=[]
 for d in DATA:
  for p in ['default','validation_constrained','coverage_0.10','coverage_0.20','coverage_0.30']:
   for m in NAMES:
    rows=[x for x in r['results'] if x['dataset']==d and x['policy']==p and x['model']==m]
    summary.append(dict(dataset=d,policy=p,model=m,**aggregate(rows)))
 with (OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]),delimiter=';');w.writeheader();w.writerows(summary)
 (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
 seed_rows=[]
 for x in r['results']:
  if x['policy'] in ('default','validation_constrained'):
   seed_rows.append({k:x[k] for k in ['dataset','seed','model','policy','n','n_other','approved','rejected','coverage','dangerous','wrong_category','wrong_reject','selective_error']})
 with (OUT/'seed_dispersion.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(seed_rows[0]),delimiter=';');w.writeheader();w.writerows(seed_rows)
 latency_summary={d:{m:statistics.median(x['per_item_ms'] for x in r['latency'] if x['dataset']==d and x['model']==m) for m in NAMES} for d in DATA}
 (OUT/'latency_summary.json').write_text(json.dumps({'method':'median across 10 seed values; each value is median of 5 batch timings divided by batch size; milliseconds per item','values':latency_summary},ensure_ascii=False,indent=2),encoding='utf-8')
 curves=list(csv.DictReader((OUT/'threshold_curves.csv').open(encoding='utf-8-sig'),delimiter=';'))
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12})
 colors=['#7c6f64','#185c82','#2b887a','#b46039']
 fig,axes=plt.subplots(1,2,figsize=(9.2,4),dpi=200)
 for ax,d in zip(axes,DATA):
  for m,color in zip(NAMES,colors):
   points=[]
   for t in r['protocol']['threshold_grid']:
    rows=[x for x in curves if x['dataset']==d and x['model']==m and float(x['threshold'])==t]
    n=sum(int(x['n']) for x in rows); no=sum(int(x['n_other']) for x in rows)
    points.append((100*sum(int(x['approved'])+int(x['rejected']) for x in rows)/n,100*sum(int(x['dangerous']) for x in rows)/no))
   points.sort()
   ax.plot(*zip(*points),marker='.',lw=1.4,label=NAMES[m],color=color)
  ax.set_title(DATA[d],fontsize=12); ax.set_xlabel('Автоматические решения, %')
  ax.set_ylabel('Ошибочно одобрено среди нецелевых, %'); ax.grid(alpha=.2);ax.set_xlim(left=0);ax.set_ylim(bottom=0)
 axes[0].legend(fontsize=10)
 fig.suptitle('Тестовые кривые при едином пороге одобрения и отказа',fontsize=12)
 fig.tight_layout();fig.savefig(OUT/'risk_coverage.png');fig.savefig(OUT/'risk_coverage.svg');plt.close(fig)
 selected=[x for x in r['results'] if x['dataset']=='regional' and x['model']=='current_char' and x['policy']=='validation_constrained']
 fig,ax=plt.subplots(figsize=(8,2.7),dpi=220)
 ax.bar([x['seed'] for x in selected],[x['dangerous'] for x in selected],color='#555555',width=.65)
 for x in selected:
  if x['dangerous']:ax.text(x['seed'],x['dangerous']+.5,str(x['dangerous']),ha='center',fontsize=13)
 ax.set_xticks(list(range(10)));ax.set_xlabel('Номер разбиения (seed)');ax.set_ylabel('Опасные одобрения, шт.');ax.set_ylim(0,28)
 ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);fig.tight_layout()
 fig.savefig(OUT/'seed_dispersion.png');fig.savefig(OUT/'seed_dispersion.svg');plt.close(fig)

 # Seed bootstrap describes split sensitivity, not independent population sampling.
 rng=np.random.default_rng(20261113); boots=[]
 for d in DATA:
  for m in ['regularized_char','hybrid']:
   for field in ['coverage','dangerous_rate','accuracy']:
    a=[x for x in r['results'] if x['dataset']==d and x['policy']=='default' and x['model']=='current_char']
    b=[x for x in r['results'] if x['dataset']==d and x['policy']=='default' and x['model']==m]
    delta=np.array([y[field]-x[field] for x,y in zip(a,b)])
    dist=delta[rng.integers(0,len(delta),size=(10000,len(delta)))].mean(axis=1)
    lo,hi=np.quantile(dist,[.025,.975])
    boots.append(dict(dataset=d,candidate=m,metric=field,mean_delta=float(delta.mean()),seed_bootstrap_p025=float(lo),seed_bootstrap_p975=float(hi)))
 (OUT/'split_sensitivity.json').write_text(json.dumps(boots,indent=2),encoding='utf-8')

 lines=['# Техническое приложение к исследованию SmartRubleAI','',
 'Дата выполнения: 13 ноября 2026 года. Все товары, решения и сметы синтетические. '+
 'Региональный набор составлен авторами; это не официальный перечень допустимых расходов и не данные регионального пилота.',
 '', '## Проверка исходных цифр','',
 'При пяти seed 0–4 и 160 примерах на класс воспроизведены 1 106 тестовых предъявлений, '+
 '583 правильных ответа (52,71%), 156 автоматических решений (14,10% при округлении точного отношения), '+
 'одно ошибочное одобрение среди 239 нецелевых позиций (0,42%), четыре ошибочных отказа среди 867 допустимых. '+
 'Возможный источник значения 14,11% в старом тексте — повторное округление уже округлённой доли 0,14105 из JSON. '+
 'Для новой статьи все проценты вычисляются из целых счётчиков. Таблицы старого сравнения правил и кандидата не перенесены: '+
 'их точная конфигурация на 1 106 предъявлениях не установлена. Документ исследовательской ветки описывает другой, трёхseedовый эксперимент на 670 предъявлениях.',
 '', '## Дизайн','',
 'Исходный набор: генератор проекта, пять категорий, 240 примеров на категорию, seed 0–9. '+
 'Разделение по базовым названиям внутри каждого класса: 60% обучение, 20% валидация, остаток тест; '+
 'границы округляются вниз. TF-IDF обучается только на обучающей части. Тест не участвует в подборе порогов.',
 '', 'Региональный набор: 80 фраз, по 12 вариантов, 960 строк за запуск; четыре класса. '+
 'Группы синонимов заранее объединены в семейства рубашек, жилетов, брюк и др. '+
 'Группы разных выборок не пересекаются. Размеры теста меняются, поскольку семейства имеют разное число фраз. '+
 'Первый пилот с разделением только по буквальному названию показал завышенную оценку и исключён из итоговых таблиц. '+
 'После ужесточения группирования запуск выполнен заново; исследование остаётся разведочным, внешней предрегистрации нет.',
 '', 'Все модели отдельно переобучены для каждой предметной области и seed. '+
 'Региональные категории используются только в исследовательском скрипте и не добавлены в интерфейс приложения. '+
 'Гибридная модель объединяет TF-IDF символов и слов, а не семантические эмбеддинги. '+
 'Базовые правила извлекают из train токены длиной от четырёх букв, встречающиеся минимум дважды в единственном классе; '+
 'при отсутствии признаков или равенстве голосов возвращают REVIEW. Это одна конкретная слабая эвристика, не все системы правил.',
 '', '## Политики решений','',
 'Исходные пороги: одобрение 0,8, отказ 0,6. '+
 'Настраиваемая политика максимизирует автоматизацию при нуле опасных одобрений и ошибок статьи сметы на валидации '+
 'и не более 2% ошибочных отказов среди допустимых; сетка 0,30–1,00 с шагом 0,05 плюс 1,01 (полное воздержание). '+
 'При равенстве выбираются более высокие пороги. Эти ограничения не являются гарантией на тесте.',
 '', 'Для сопоставления автоматизации пороги подбираются под целевые 10%, 20% и 30% на валидации. '+
 'Сначала минимизируется отклонение от целевого покрытия, затем число ошибочных автоматических решений. '+
 'У правил дискретные оценки, поэтому нужное покрытие может быть недостижимо. '+
 'На тесте фактические доли также различаются; объявлять их экспериментом при строго одинаковом тестовом покрытии нельзя.',
 '', '## Определения показателей','',
 'Accuracy = правильная категория / все позиции; REVIEW правил при этом считается отсутствием правильной классификации. '+
 'Coverage = (APPROVE + REJECT) / все позиции. Опасное одобрение = APPROVE истинного other. '+
 'Его частота делится на число истинных other, не на все операции. Ошибка статьи = APPROVE допустимого товара '+
 'с неверной разрешённой категорией. Ошибочный отказ = REJECT допустимого товара. '+
 'Selective error = сумма трёх видов ошибок / все автоматические решения; при нуле решений не определена.',
 '', '## Итоговые таблицы','']
 for d in DATA:
  for policy in ['default','validation_constrained','coverage_0.20']:
   lines+=['### '+DATA[d]+' — '+policy,'','| Модель | Точность | Автоматизация | Опасные / нецелевые | Ошибки статьи | Ошибочные отказы | Все ошибки / автоматические |','|---|---:|---:|---:|---:|---:|---:|']
   for x in summary:
    if x['dataset']==d and x['policy']==policy:
     lines.append(f"| {NAMES[x['model']]} | {pct(x['accuracy'])} | {pct(x['coverage'])} | {x['dangerous']} / {x['n_other']} | {x['wrong_category']} | {x['wrong_reject']} | {x['auto_errors']} / {x['approved']+x['rejected']} ({pct(x['selective_error'])}) |")
   lines+=['']
 lines+=['## Разброс по запускам','',
 '| Seed | Автоматические решения текущей региональной модели | O | K | R | Все ошибки среди автоматических |','|---|---:|---:|---:|---:|---:|']
 regional=[x for x in r['results'] if x['dataset']=='regional' and x['model']=='current_char' and x['policy']=='validation_constrained']
 for x in regional:
  lines.append(f"| {x['seed']} | {x['approved']+x['rejected']} | {x['dangerous']} | {x['wrong_category']} | {x['wrong_reject']} | {pct(x['selective_error'])} |")
 lines+=['', '24 из 33 опасных одобрений сосредоточены в seed=1, ещё 4 в seed=2 и 5 в seed=3. '+
 'В остальных семи разбиениях опасных одобрений нет. Суммарно 151 из 440 автоматических решений ошибочны (34,32%). '+
 'Малая итоговая частота по всем нецелевым позициям скрывает локальную концентрацию ошибок. '+
 'Полный разброс для всех моделей и обеих политик сохранён в seed_dispersion.csv.',
 '', '## Интерпретация','',
 'Главный результат — ограничения переносимости политики, выбранной по небольшому синтетическому набору. '+
 'Отсутствие опасных одобрений на исходной предметной области не переносится на региональную. '+
 'Усиление регуляризации снижает число опасных одобрений региональных товаров при фиксированных порогах, '+
 'но одновременно снижает автоматизацию. Сравнение при общем целевом покрытии валидации не даёт устойчивого победителя. '+
 'Доказательств безопасного улучшения для замены модели v0.5.0 не получено.',
 '', '## Неоднозначные описания','',
 'Двенадцать отдельных фраз не содержат достаточно сведений для разрешения покупки. Ожидается REVIEW. '+
 'При настроенной политике число автоматических решений из 120 предъявлений по десяти seed: '+
 '; '.join(NAMES[m]+': '+str(sum(x['decision']!='REVIEW' for x in r['ambiguity'] if x['model']==m)) for m in NAMES)+'. '+
 'Повторные предъявления одной фразы зависимы. Эти фразы не смешиваются с обычной accuracy и не использовались для донастройки порогов.',
 '', '## Сквозной контроль','',
 'Настоящий SmartContract проверен с детерминированными ответами тестового классификатора: '+
 'смешанный чек, ручное решение, превышение лимита, повторная подача и хэш-цепочка. '+
 'Начальная смета 300 ₽, окончательно списано 200 ₽, остаток 100 ₽. '+
 'Этот сценарий проверяет финансовую логику отдельно от качества ML. Он отличается от демонстрации Honor на 175/200 ₽.',
 '', '## Время и экономика','',
 'Измерена медиана пяти повторов пакетного предсказания после обучения; время подготовки, API, сети и человека исключено. '+
 'Для текущей модели медиана по seed: '+
 '; '.join(DATA[d]+': '+f"{statistics.median(x['per_item_ms'] for x in r['latency'] if x['dataset']==d and x['model']=='current_char'):.4f}"+' мс на позицию' for d in DATA)+'. '+
 'Это амортизированное время пакета, а не задержка одиночного запроса. Время человека не измерялось.',
 '', 'Сценарная формула: T = N × t_система + N × (1 − coverage) × t_ручная + '+
 'N × coverage × q × t_аудит + F. Здесь q — доля выборочного контроля автоматических решений, '+
 'F — фиксированные затраты времени. Для иллюстрации N=1000, t_ручная=30 с, t_система=1 с, '+
 'q=10%, t_аудит=30 с, F=0 и coverage=37,05% дают около 350 минут против 500 минут полностью ручной работы. '+
 'Это расчёт с предположениями, а не измеренная экономия; он исключает стоимость ошибок и внедрения и потому не доказывает целесообразность.',
 '', '## Устойчивость и ограничения','',
 'Десять разбиений переиспользуют один каталог товаров, а варианты одного семейства зависимы. '+
 'Суммы в таблицах — тестовые предъявления, не число независимых уникальных покупок. '+
 'Файл split_sensitivity.json содержит парный bootstrap средних различий по seed (10 000 повторов), '+
 'используемый только как характеристика чувствительности к разбиению. Это не доверительный интервал риска реальной эксплуатации и не тест статистической значимости.',
 '', 'Нужны независимая разметка, внешний каталог, реальные обезличенные наименования при наличии прав доступа, '+
 'валидация доверенности сведений продавца и оценки времени операторов. Калибровка вероятностей и модели на эмбеддингах '+
 'не проверены. Интерфейс, авторизация, постоянная БД и банковская интеграция в рамках исследования не реализовывались.',
 '', '## Воспроизведение','',
 'Из корня распакованного репозитория на Windows:','',
 '```powershell','uv venv --python 3.14 .venv','uv pip install --python .venv\\Scripts\\python.exe -r requirements-article-lock.txt',
 '.venv\\Scripts\\python.exe -X utf8 scripts\\article_study.py',
 '.venv\\Scripts\\python.exe -X utf8 scripts\\article_package.py',
 '.venv\\Scripts\\python.exe -m unittest discover -s tests -p test_article_study.py -v','```','',
 'Результаты записываются в ../outputs/article-evidence-v31 относительно корня репозитория. '+
 'Git не требуется: без локального .git исходный коммит берётся из SOURCE_VERSION.json; отсутствие обеих меток явно отражается как unavailable. '+
 'Время выполнения зависит от ноутбука; счётчики и разбиения детерминированы при зафиксированном окружении. '+
 'Файлы CSV содержат UTF-8 BOM и разделитель «;».','', '## Окружение','',
 '```json',json.dumps(r['environment'],ensure_ascii=False,indent=2),'```']
 (OUT/'TECHNICAL_APPENDIX.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print('Package summaries and figure ready')

if __name__=='__main__':main()
