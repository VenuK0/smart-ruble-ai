"""Article experiment, isolated from the application's production classifier.

Run from repository root: .venv/Scripts/python.exe -X utf8 scripts/article_study.py
Synthetic evidence only. Protocol is fixed in PROTOCOL before running.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import random
import re
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'scripts'))
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, make_pipeline
from threadpoolctl import threadpool_limits
from smartruble.data import BASES, make_items, split_by_base
from forum_evidence import classification, review_workflow

OUT = ROOT.parent / 'outputs' / 'article-evidence-v31'
MODELS = ('rules', 'current_char', 'regularized_char', 'hybrid')
PROTOCOL = {
    'version': '1.1', 'seeds': list(range(10)), 'samples_per_class': 240,
    'split': 'per class: 60% base names train, 20% validation, remainder test; floor rounding',
    'models': list(MODELS), 'C': {'current_char': 8, 'regularized_char': 2, 'hybrid': 8},
    'threshold_grid': [round(x, 2) for x in np.arange(.30, 1.001, .05)] + [1.01],
    'selected_policy': 'max validation coverage with zero false approvals, zero approved category errors, and <=2% false rejection of eligible items; tie: higher approval then rejection threshold',
    'matched_validation_coverage': [.10, .20, .30],
    'matched_policy': 'closest validation coverage; tie: fewest incorrect auto decisions; then higher thresholds',
    'test_usage': 'evaluate frozen policies and predeclared common-threshold curves only; no candidate selection on test',
    'uncertainty': 'seed min/max and paired seed bootstrap; repeated synthetic splits are dependent, not population confidence intervals',
    'regional_scope': 'author-defined synthetic school and sports clothing policy, not official eligibility rules',
    'regional_grouping': 'synonym families fixed manually before final run; initial exact-name-only pilot discarded as optimistic',
    'ambiguity': 'separate challenge set requiring REVIEW; excluded from ordinary label accuracy',
}

REGIONAL = {
 'uniform_top': ['школьная рубашка белая','школьная блузка хлопковая','школьный жилет синий','школьный пиджак серый','форменный жакет детский','школьная сорочка','школьный кардиган','форменная безрукавка','жилетка ученическая','блузон школьный','школьная водолазка','рубашка ученическая','пиджак для ученика','жакет для ученицы','блуза школьная','сорочка для школы','кардиган ученический','школьный пуловер','форменный джемпер','школьный свитер'],
 'uniform_bottom': ['школьные брюки черные','школьная юбка синяя','школьный сарафан','форменные штаны','юбка для ученицы','брюки для ученика','сарафан ученический','школьные кюлоты','школьная юбка плиссе','форменные брюки прямые','юбка школьная клетчатая','брюки школьные зауженные','сарафан для школы','школьная юбка карандаш','ученические брюки','форменная юбка','полукомбинезон школьный','школьные брюки классические','юбка ученицы','сарафан форменный'],
 'sports': ['спортивная футболка детская','спортивные шорты','спортивные брюки','спортивный костюм детский','майка для физкультуры','форма для физкультуры','спортивная кофта','трико для физкультуры','олимпийка детская спортивная','легинсы для физкультуры','футболка для физкультуры','шорты для физкультуры','спортивная толстовка','штаны тренировочные детские','джемпер спортивный','спортивный лонгслив','майка тренировочная','костюм для физкультуры','брюки для физкультуры','футболка тренировочная'],
 'other': ['школьный рюкзак','пенал школьный','тетрадь школьная','школьные туфли','спортивные кроссовки','спортивная сумка','школьный дневник','школьный галстук','спортивный мяч','игровая приставка','шоколадный батончик','повседневные джинсы','вечернее платье','детская игрушка','зимняя куртка','смартфон','спортивные носки','школьный бант','спортивная бутылка','канцелярский набор'],
}
AMBIGUOUS = ['форма детская','комплект школьный','одежда детская','товар по акции','набор для школы','текстиль детский','позиция 001','комплект ученический','форма универсальная','костюм детский','изделие швейное','набор школьника']
# Canonical product families, matching catalog order. Synonyms cannot cross partitions.
REGIONAL_FAMILIES = {
 'uniform_top': ['shirt','blouse','vest','jacket','jacket','shirt','cardigan','vest','vest','blouse','knit','shirt','jacket','jacket','blouse','shirt','cardigan','knit','knit','knit'],
 'uniform_bottom': ['trousers','skirt','pinafore','trousers','skirt','trousers','pinafore','culottes','skirt','trousers','skirt','trousers','pinafore','skirt','trousers','skirt','overall','trousers','skirt','pinafore'],
 'sports': ['tshirt','shorts','trousers','suit','tshirt','suit','jacket','trousers','jacket','leggings','tshirt','shorts','jacket','trousers','jacket','tshirt','tshirt','suit','trousers','tshirt'],
 'other': ['bag','pencilcase','notebook','shoes','shoes','bag','diary','tie','ball','console','food','jeans','dress','toy','coat','phone','socks','bow','bottle','stationery'],
}

def split_three(rows, seed):
    rng = random.Random(seed)
    groups = {}
    for _, label, base in rows:
        groups.setdefault(label, set()).add(base)
    partitions = [set(), set(), set()]
    for label in sorted(groups):
        bases = sorted(groups[label]); rng.shuffle(bases)
        a, b = int(.6 * len(bases)), int(.2 * len(bases))
        for target, chunk in zip(partitions, (bases[:a], bases[a:a+b], bases[a+b:])):
            target.update(chunk)
    assert all(not partitions[i] & partitions[j] for i in range(3) for j in range(i))
    result = [[r for r in rows if r[2] in p] for p in partitions]
    assert sum(map(len, result)) == len(rows)
    return result, [sorted(p) for p in partitions]

def regional_rows(seed):
    rng = random.Random(seed)
    rows = []
    # Exactly 12 variants/base; no category-specific modifiers or prices.
    for label, bases in REGIONAL.items():
        for base, family in zip(bases, REGIONAL_FAMILIES[label]):
            for i in range(12):
                text = base + rng.choice(['', ' размер 140', ' арт 4821', ' синий', ' комплект', ' 1 шт'])
                if i % 4 == 0: text = text.upper()
                if i % 7 == 0 and len(text) > 10:
                    k = rng.randrange(1, len(text)-1); text = text[:k] + text[k+1:]
                rows.append((text, label, label + ':' + family))
    rng.shuffle(rows)
    return rows

class Rules:
    """Training-only token evidence; ties/absent tokens abstain. Not all rules systems."""
    def fit(self, names, labels):
        self.counts = {}
        for name, label in zip(names, labels):
            for token in set(re.findall(r'[а-яёa-z]{4,}', name.lower())):
                self.counts.setdefault(token, Counter())[label] += 1
        return self
    def predict_many(self, names):
        result = []
        for name in names:
            votes = Counter()
            for token in set(re.findall(r'[а-яёa-z]{4,}', name.lower())):
                counts = self.counts.get(token, {})
                # A token must occur >=2 times and only in one training category.
                if len(counts) == 1 and sum(counts.values()) >= 2:
                    votes[next(iter(counts))] += 1
            ordered = votes.most_common()
            if not ordered or (len(ordered)>1 and ordered[0][1] == ordered[1][1]):
                result.append(('abstain', 0.))
            else:
                result.append((ordered[0][0], ordered[0][1] / sum(votes.values())))
        return result

def model(name):
    if name == 'rules': return Rules()
    char = TfidfVectorizer(analyzer='char_wb', ngram_range=(2,5), sublinear_tf=True)
    features = char
    if name == 'hybrid':
        features = FeatureUnion([('char', char), ('word', TfidfVectorizer(ngram_range=(1,2), sublinear_tf=True))])
    return make_pipeline(features, LogisticRegression(max_iter=1000, C=PROTOCOL['C'][name], random_state=0))

def predict(m, names):
    if isinstance(m, Rules): return m.predict_many(names)
    prob = m.predict_proba(names)
    return [(str(m.classes_[int(p.argmax())]), float(p.max())) for p in prob]

def decisions(predictions, approval=.8, rejection=.6):
    return ['REVIEW' if p == 'abstain' else
            'REJECT' if p == 'other' and c >= rejection else
            'APPROVE' if p != 'other' and c >= approval else 'REVIEW' for p,c in predictions]

def metrics(rows, pred, approval=.8, rejection=.6):
    ds = decisions(pred, approval, rejection)
    y = [r[1] for r in rows]; n = len(y)
    count = lambda f: sum(f(t,p,d) for t,(p,c),d in zip(y,pred,ds))
    other = sum(t=='other' for t in y); allowed = n-other
    a = ds.count('APPROVE'); r = ds.count('REJECT')
    dangerous = count(lambda t,p,d: t=='other' and d=='APPROVE')
    wrong_category = count(lambda t,p,d: t!='other' and t!=p and d=='APPROVE')
    wrong_reject = count(lambda t,p,d: t!='other' and d=='REJECT')
    return dict(n=n, n_other=other, n_allowed=allowed,
        correct=count(lambda t,p,d:t==p), approved=a, rejected=r, review=n-a-r,
        dangerous=dangerous, wrong_category=wrong_category, wrong_reject=wrong_reject,
        accuracy=count(lambda t,p,d:t==p)/n, coverage=(a+r)/n,
        dangerous_rate=dangerous/other if other else None,
        category_error_rate=wrong_category/a if a else None,
        wrong_reject_rate=wrong_reject/allowed if allowed else None,
        selective_error=(dangerous+wrong_category+wrong_reject)/(a+r) if a+r else None)

def select_policies(rows, pred):
    candidates = []
    for a in PROTOCOL['threshold_grid']:
        for r in PROTOCOL['threshold_grid']:
            m = metrics(rows,pred,a,r)
            candidates.append((a,r,m))
    safe = [x for x in candidates if x[2]['dangerous']==0 and x[2]['wrong_category']==0 and x[2]['wrong_reject_rate']<=.02]
    chosen = max(safe, key=lambda x:(x[2]['coverage'],x[0],x[1]))
    result = {'default':(.8,.6), 'validation_constrained':chosen[:2]}
    for target in PROTOCOL['matched_validation_coverage']:
        selected = min(candidates, key=lambda x:(abs(x[2]['coverage']-target),
            x[2]['dangerous']+x[2]['wrong_category']+x[2]['wrong_reject'], -x[0], -x[1]))
        result[f'coverage_{target:.2f}'] = selected[:2]
    return result

def csv_write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0]), delimiter=';'); writer.writeheader(); writer.writerows(rows)

def source_version(root=ROOT):
    """Only inspect this checkout; extracted ZIPs must not inherit a parent repo."""
    manifest = root / 'SOURCE_VERSION.json'
    declared = json.loads(manifest.read_text(encoding='utf-8-sig')) if manifest.exists() else {}
    if (root / '.git').exists():
        try:
            commit = subprocess.check_output(['git','rev-parse','main'],cwd=root,text=True,stderr=subprocess.DEVNULL).strip()
            return {'base_commit':commit,'version_source':'git_main'}
        except (OSError,subprocess.CalledProcessError):
            pass
    return {'base_commit':declared.get('base_commit'),
            'version_source':'source_manifest' if declared.get('base_commit') else 'unavailable'}

def main():
    global OUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=OUT)
    OUT=parser.parse_args().output.resolve()
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'protocol.json').write_text(json.dumps(PROTOCOL,ensure_ascii=False,indent=2),encoding='utf-8')
    results=[]; curves=[]; predictions=[]; splits=[]; ambiguity=[]; latency=[]
    start=time.perf_counter()
    with threadpool_limits(limits=1):
      legacy=classification(list(range(5)),160)
      workflow=review_workflow()
      for dataset in ('original','regional'):
        for seed in PROTOCOL['seeds']:
          rows=make_items(240,seed) if dataset=='original' else regional_rows(seed)
          (train,val,test),parts=split_three(rows,seed)
          splits.append(dict(dataset=dataset,seed=seed,train=parts[0],validation=parts[1],test=parts[2]))
          for name in MODELS:
            m=model(name).fit([r[0] for r in train],[r[1] for r in train])
            vp=predict(m,[r[0] for r in val]); tp=predict(m,[r[0] for r in test])
            # Clock only batch prediction, excluding model training and UI/network.
            times=[]
            for _ in range(5):
                tick=time.perf_counter(); predict(m,[r[0] for r in test]); times.append(time.perf_counter()-tick)
            latency.append(dict(dataset=dataset,seed=seed,model=name,n=len(test),batch_ms=1000*float(np.median(times)),per_item_ms=1000*float(np.median(times))/len(test)))
            policies=select_policies(val,vp)
            for policy,(a,r) in policies.items():
                vm=metrics(val,vp,a,r); tm=metrics(test,tp,a,r)
                results.append(dict(dataset=dataset,seed=seed,model=name,policy=policy,approval=a,rejection=r,validation_coverage=vm['coverage'],validation_dangerous=vm['dangerous'],validation_wrong_category=vm['wrong_category'],**tm))
            for t in PROTOCOL['threshold_grid']:
                curves.append(dict(dataset=dataset,seed=seed,model=name,threshold=t,**metrics(test,tp,t,t)))
            ap,rr=policies['validation_constrained']
            ds=decisions(tp,ap,rr)
            for row,(p,c),d in zip(test,tp,ds):
                predictions.append(dict(dataset=dataset,seed=seed,model=name,text=row[0],true=row[1],base=row[2],predicted=p,score=c,decision=d))
            if dataset=='regional':
                ps=predict(m,AMBIGUOUS); dd=decisions(ps,ap,rr)
                for text,(p,c),d in zip(AMBIGUOUS,ps,dd):
                    ambiguity.append(dict(seed=seed,model=name,text=text,predicted=p,score=c,decision=d,expected='REVIEW'))
          print(dataset, seed, 'completed', flush=True)
    report={'protocol':PROTOCOL,'legacy':legacy,'workflow':workflow,'results':results,'splits':splits,
      'ambiguity':ambiguity,'latency':latency,
      'environment':{'python':platform.python_version(),'platform':platform.platform(),
       'packages':{p:importlib.metadata.version(p) for p in ('scikit-learn','numpy','scipy','matplotlib')},
       **source_version(),
       'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'elapsed_seconds':time.perf_counter()-start}}
    (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    for filename,content in [('policies.csv',results),('threshold_curves.csv',curves),('predictions.csv',predictions),('ambiguity.csv',ambiguity),('latency.csv',latency)]: csv_write(OUT/filename,content)
    (OUT/'regional_catalog.json').write_text(json.dumps({'categories':REGIONAL,'families_in_catalog_order':REGIONAL_FAMILIES,'ambiguous':AMBIGUOUS},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Legacy:', json.dumps(legacy['totals']),flush=True)
    print('DONE', OUT,flush=True)

if __name__=='__main__': main()
