"""Build the concise bilingual conference draft; full evidence is a separate appendix."""
from pathlib import Path
import json,re,statistics
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE=Path(__file__).resolve().parents[2]; OUT=BASE/'outputs';E=OUT/'article-evidence-v31'
R=json.loads((E/'results.json').read_text(encoding='utf-8'))
S=json.loads((E/'summary.json').read_text(encoding='utf-8'))
L=json.loads((E/'latency_summary.json').read_text(encoding='utf-8'))['values']
doc=Document();sec=doc.sections[0]
sec.page_height=Cm(29.7);sec.page_width=Cm(21)
sec.top_margin=sec.bottom_margin=sec.left_margin=sec.right_margin=Cm(2)
for st in doc.styles:
 if st.type in (1,2):
  st.font.name='Times New Roman';st.font.size=Pt(14);st.font.color.rgb=RGBColor(0,0,0)
  rf=st.element.get_or_add_rPr().get_or_add_rFonts()
  for key in list(rf.attrib):
   if 'theme' in key.lower():del rf.attrib[key]
  for key in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+key),'Times New Roman')
 if st.type==1:
  st.paragraph_format.line_spacing=1.5
  st.paragraph_format.space_before=st.paragraph_format.space_after=Pt(0)
  st.paragraph_format.first_line_indent=Cm(0)
 for tag in ['pBdr','numPr','spacing']:
  # Character spacing from the template is decorative; paragraph spacing is set above.
  if tag=='spacing':continue
  for el in list(st.element.iter(qn('w:'+tag))):el.getparent().remove(el)
doc.styles['Title'].font.bold=True
doc.styles['Title'].font.italic=False
doc.styles['Normal'].paragraph_format.first_line_indent=Cm(1.25)
doc.core_properties.title='Контроль целевых расходов в SmartRubleAI'
doc.core_properties.author='Окунев В. И.; Штунь А. Р.; Рзун И. Г.'
doc.core_properties.comments=''
md=[]
def p(text,center=False,bold=False,indent=True,keep=False,style=None):
 text=re.sub(r'(?<=\d) (?=\d{3}(?:\D|$))','\u00a0',text)
 q=doc.add_paragraph(text,style=style)
 q.alignment=WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.JUSTIFY
 q.paragraph_format.first_line_indent=Cm(1.25 if indent and not center else 0)
 q.paragraph_format.keep_with_next=keep
 if bold:
  for run in q.runs:run.bold=True
 md.append(text+'\n');return q

ru_ann='На синтетических товарах показано: настройка порогов SmartRubleAI снижает опасные одобрения ценой автоматизации, но не устраняет ошибки на новых семействах.'
en_ann='Synthetic tests show that tuning SmartRubleAI thresholds reduces unsafe approvals at the cost of automation but does not eliminate errors on unseen product families.'
assert len(ru_ann)<=200 and len(en_ann)<=200
p('УДК 004.89',indent=False)
p('Контроль целевых расходов в SmartRubleAI',center=True,bold=True,style='Title')
p('Окунев В. И., Штунь А. Р. — студенты;\nРзун И. Г. — научный руководитель',center=True)
p('Новороссийский филиал Финансового университета\nпри Правительстве Российской Федерации',center=True)
p('Аннотация. '+ru_ann,indent=False)
p('Ключевые слова: целевые расходы, цифровой рубль, классификация.',indent=False)
p('Targeted expenditure control in SmartRubleAI',center=True,bold=True)
p('V. I. Okunev, A. R. Shtun, students;\nI. G. Rzun, research supervisor',center=True)
p('Novorossiysk Branch of the Financial University\nunder the Government of the Russian Federation',center=True)
p('Abstract. '+en_ann,indent=False)
p('Keywords: targeted expenditure, digital ruble, classification.',indent=False)

p('Возможности цифрового рубля для бюджетного контроля обсуждаются в российских исследованиях [1; 2]. Банк России описывает региональные испытания, включая субсидии на школьную и спортивную форму [3, с. 6–7]. Мы проверяем, позволяет ли настройка классификатора увеличить автоматизацию контроля без роста ошибок. SmartRubleAI — локальная симуляция без банковской интеграции.')
p('Сравнены правила по обучающим токенам, символьный TF-IDF 2–5 с логистической регрессией C=8, вариант C=2 и гибрид символьных и словесных признаков. Для каждого из десяти разбиений семейства товаров разделены на обучение, валидацию и тест примерно как 60/20/20. Синонимы региональных товаров объединены. Пороги выбирались только на валидации [4].')
p('Первый синтетический набор содержит пять категорий и 2 555 тестовых предъявлений по десяти разбиениям. На нём текущая модель при порогах 0,8/0,6 не одобрила ни одной из 491 нецелевых позиций, но допустила 64 ошибки статьи сметы и 46 ложных отказов. Повторные предъявления зависимы и не являются независимыми покупками.')
p('Второй набор — авторская модель школьной и спортивной одежды: 80 фраз, по 12 вариантов. Обувь, мячи и бутылки исключены по условиям модели, а не по нормативному перечню. Классификаторы переобучены на четыре категории; итоговый тест содержит 2 880 предъявлений, включая 672 нецелевых.')
p('Пороги максимизировали автоматизацию при нуле опасных одобрений и ошибок статьи на валидации и не более 2% ложных отказов среди допустимых товаров. Сетка — 0,30–1,00 с шагом 0,05 плюс отключение решения. В таблице A — автоматические решения, C — их доля, O — одобрения нецелевых товаров, K — неверная статья, R — ложные отказы; E=(O+K+R)/A.')
p('Таблица 1. Региональные результаты настроенных политик',bold=True,indent=False,keep=True)
headers=['Модель','A','C, %','O','K','R','E, %']
names={'rules':'Правила','current_char':'TF-IDF C=8','regularized_char':'TF-IDF C=2','hybrid':'Гибрид'}
table=doc.add_table(rows=1,cols=7);table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
widths=[3.6,1.8,2.4,1.5,1.5,1.5,2.4]
for c,w,t in zip(table.rows[0].cells,widths,headers):c.width=Cm(w);c.text=t
md.extend(['| '+' | '.join(headers)+' |','|---|---:|---:|---:|---:|---:|---:|'])
for name in names:
 x=next(x for x in S if x['dataset']=='regional' and x['policy']=='validation_constrained' and x['model']==name)
 fmt=lambda v:f'{100*v:.2f}'.replace('.',',')
 values=[names[name],str(x['approved']+x['rejected']),fmt(x['coverage']),str(x['dangerous']),str(x['wrong_category']),str(x['wrong_reject']),fmt(x['selective_error'])]
 for c,w,t in zip(table.add_row().cells,widths,values):c.width=Cm(w);c.text=t
 md.append('| '+' | '.join(values)+' |')
for i,row in enumerate(table.rows):
 row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
 for j,cell in enumerate(row.cells):
  cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
  pr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
  for edge in ['top','left','bottom','right']:
   el=OxmlElement('w:'+edge);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
  pr.append(borders)
  if i==0:
   fill=OxmlElement('w:shd');fill.set(qn('w:fill'),'E6E6E6');pr.append(fill)
  for q in cell.paragraphs:
   q.paragraph_format.first_line_indent=Cm(0);q.paragraph_format.line_spacing=1.5
   q.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
   for run in q.runs:run.font.size=Pt(14);run.bold=i==0
table.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))

p('У текущей модели настройка снизила опасные одобрения со 113 до 33 (из 672), а автоматизацию — с 37,05 до 15,28%. Однако ошибочны 151 из 440 автоматических решений (34,32%). Из 33 опасных одобрений 24 пришлись на seed=1, четыре — на seed=2, пять — на seed=3; в остальных семи разбиениях их нет. Итоговая сумма скрывает нестабильность переноса порогов.')
q=doc.add_paragraph();q.paragraph_format.first_line_indent=Cm(0);q.paragraph_format.keep_with_next=True
q.add_run().add_picture(str(E/'seed_dispersion.png'),width=Cm(16.5))
md.append('![Разброс опасных одобрений](article-evidence-v31/seed_dispersion.png)\n')
p('Рисунок 1. Опасные одобрения настроенной текущей модели в десяти зависимых региональных разбиениях',indent=False)
p('Одинаковая цель автоматизации на валидации также не обеспечивает одинакового покрытия на тесте. При цели 20% текущая модель и вариант C=2 достигли на исходном наборе 17,22 и 22,15%. Поэтому снижение ошибок нельзя целиком приписывать качеству классификатора: нужно учитывать его осторожность. Оценки уверенности не калиброваны. Сходные слова в названиях спортивной одежды и мяча могут сопровождаться уверенным ошибочным допуском.')
p('Гипотеза устойчивого безопасного увеличения автоматизации не подтверждена. Оценивать нужно все три вида ошибок, нагрузку на человека и разброс по семействам. Результаты относятся к малому авторскому синтетическому каталогу. Время пакетного предсказания и полные таблицы приведены в приложении; время операторов и экономия не измерялись. Код воспроизводится из ZIP без Git [5].')

p('Список источников',bold=True,indent=False,keep=True)
refs=[
'1. Унижаев Н. В. Анализ преимуществ финансового контроля с использованием цифрового рубля // Вопросы инновационной экономики. 2023. Т. 13. № 2. С. 821–836. DOI: 10.18334/vinec.13.2.117191.',
'2. Манжула Т. Ю., Верич Ю. Л. Использование цифрового рубля в бюджетном процессе Российской Федерации // Вестник Института экономических исследований. 2025. № 2(38). С. 209–221.',
'3. Банк России. Концепция платформы коммерческих смарт-контрактов. 2026. URL: https://www.cbr.ru/Content/Document/File/193705/commercial_smart_contract_platform.pdf (13.11.2026).',
'4. Scikit-learn. Tuning the decision threshold for class prediction. URL: https://scikit-learn.org/stable/modules/classification_threshold.html (13.11.2026).',
'5. SmartRubleAI. Исследовательский пакет Article v3.1. 2026. Исходный прототип: https://github.com/VenuK0/smart-ruble-ai. Код и данные v3.1 — в сопровождающем ZIP.'
]
for text in refs:p(text,indent=False)
doc.save(OUT/'SmartRubleAI_article_v3_1.docx')
(OUT/'SmartRubleAI_article_v3_1.md').write_text('\n'.join(md),encoding='utf-8')
(E/'DOCUMENT_CHECK.json').write_text(json.dumps({'ru_abstract_characters':len(ru_ann),'en_abstract_characters':len(en_ann),'body_font_pt':14,'line_spacing':1.5,'margins_cm':2,'conference_original_requirements':'not available; values adopted from review chat, remaining parameters require author check'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Article v3.1 created; abstracts',len(ru_ann),len(en_ann))
