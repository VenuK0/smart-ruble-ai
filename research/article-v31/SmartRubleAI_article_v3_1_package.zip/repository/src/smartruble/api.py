"""REST API прототипа SmartRubleAI (симуляция контракта целевых средств).
Ядро (parser/classifier/contract/antifraud) покрыто тестами; API проверен вручную через Swagger UI (/docs).
Запуск: uvicorn smartruble.api:app --app-dir src"""
import uuid
from typing import Literal
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ConfigDict
from .parser import parse_estimate
from .classifier import ItemClassifier
from .contract import SmartContract
from .data import make_items, make_transactions
from .antifraud import detect, merchant_features, FEATURES
from .economics import scenario

app = FastAPI(title="SmartRubleAI Research Prototype", version="0.5.0",
              description="Симуляция на синтетических данных. Не подключено к инфраструктуре цифрового рубля.")
_rows = make_items(300, 0)
CLF = ItemClassifier().fit([r[0] for r in _rows], [r[1] for r in _rows])
CONTRACTS: dict[str, SmartContract] = {}


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class EstimateIn(StrictModel):
    grant_id: str = Field(min_length=1, max_length=80)
    text: str = Field(min_length=1, max_length=30000)


class Item(StrictModel):
    name: str = Field(min_length=1, max_length=250)
    qty: float = Field(default=1, gt=0, le=100000, allow_inf_nan=False)
    price: float = Field(gt=0, le=1000000000, allow_inf_nan=False)


class ReceiptIn(StrictModel):
    id: str = Field(default_factory=lambda: f"rcpt-{uuid.uuid4().hex[:12]}", min_length=1, max_length=128)
    merchant: str = Field(min_length=1, max_length=200)
    items: list[Item] = Field(min_length=1, max_length=100)


class ReviewResolutionIn(StrictModel):
    # Demonstration only: no identity verification, signatures or real payments.
    decision: Literal["APPROVE", "REJECT"]
    category: str | None = Field(default=None, max_length=80)
    note: str = Field(min_length=4, max_length=500)


@app.get("/")
def root():
    return {"status": "online", "system": "SmartRubleAI", "docs": "/docs", "demo": "/demo",
            "notice": "prototype simulation — no real digital-ruble payments"}


@app.post("/contracts")
def create_contract(body: EstimateIn):
    if body.grant_id in CONTRACTS:
        raise HTTPException(409, "Контракт уже существует")
    parsed = parse_estimate(body.text)
    if not parsed["limits"]:
        raise HTTPException(422, "В смете не найдено ни одной распознанной статьи. Выберите категорию и укажите сумму.")
    if parsed["unparsed"]:
        examples = "; ".join(parsed["unparsed"][:3])
        raise HTTPException(422, "Смета не создана: найдены нераспознанные строки: " + examples +
                            ". Исправьте строки или заполните статьи через редактор.")
    CONTRACTS[body.grant_id] = SmartContract(limits=parsed["limits"], classifier=CLF)
    return {"grant_id": body.grant_id, **parsed}


@app.post("/contracts/{grant_id}/validate")
def validate(grant_id: str, receipt: ReceiptIn):
    c = CONTRACTS.get(grant_id)
    if c is None:
        raise HTTPException(404, "Контракт не найден")
    try:
        return c.validate(receipt.model_dump())
    except ValueError as exc:
        raise HTTPException(409 if "уже использован" in str(exc) else 422, str(exc)) from exc


@app.get("/contracts/{grant_id}/reviews")
def review_queue(grant_id: str):
    contract = CONTRACTS.get(grant_id)
    if contract is None:
        raise HTTPException(404, "Контракт не найден")
    items = contract.list_reviews()
    return {"mode": "simulation", "items": items,
            "pending": sum(x["status"] == "PENDING" for x in items),
            "resolved": sum(x["status"] != "PENDING" for x in items)}


@app.post("/contracts/{grant_id}/reviews/{receipt_id}/{item_index}/resolve")
def resolve_review(grant_id: str, receipt_id: str, item_index: int, body: ReviewResolutionIn):
    contract = CONTRACTS.get(grant_id)
    if contract is None:
        raise HTTPException(404, "Контракт не найден")
    try:
        return contract.resolve_review(receipt_id, item_index, body.decision, body.category, body.note)
    except ValueError as exc:
        message = str(exc)
        status = (404 if message in ("Чек не найден", "Позиция чека не найдена")
                  else 409 if ("уже зафиксировано" in message or "Недостаточно средств" in message)
                  else 422)
        raise HTTPException(status, message) from exc


@app.get("/contracts/{grant_id}/audit")
def audit(grant_id: str):
    c = CONTRACTS.get(grant_id)
    if c is None:
        raise HTTPException(404, "Контракт не найден")
    return {"chain_valid": c.verify_log(), "entries": len(c.log), "spent": c.spent}


@app.get("/health")
def health():
    return {"status": "ok", "mode": "simulation"}


@app.get("/demo", response_class=HTMLResponse, include_in_schema=False)
def demo():
    path = Path(__file__).parent / "web" / "index.html"
    if not path.is_file():
        raise HTTPException(503, "Демо-интерфейс отсутствует")
    return path.read_text(encoding="utf-8")


@app.get("/contracts")
def list_contracts():
    return {"contracts": [
        {"grant_id": gid, "limits": contract.limits, "spent": contract.spent,
         "transactions": len(contract.processed_receipts)}
        for gid, contract in CONTRACTS.items()
    ]}


@app.get("/contracts/{grant_id}")
def contract_info(grant_id: str):
    contract = CONTRACTS.get(grant_id)
    if contract is None:
        raise HTTPException(404, "Контракт не найден")
    return {"grant_id": grant_id, "limits": contract.limits, "spent": contract.spent,
            "remaining": {cat: contract.remaining(cat) for cat in contract.limits},
            "transactions": len(contract.processed_receipts),
            "audit_valid": contract.verify_log()}


@app.get("/contracts/{grant_id}/history")
def history(grant_id: str):
    contract = CONTRACTS.get(grant_id)
    if contract is None:
        raise HTTPException(404, "Контракт не найден")
    # Original receipt entries remain immutable; review decisions are separate
    # hash-chained events and must never be presented as receipt rows.
    receipts = [entry for entry in contract.log
                if entry["record"].get("event_type") != "review_resolution"]
    return {"chain_valid": contract.verify_log(),
            "entries": [{"ts": entry["ts"], "record": entry["record"]}
                        for entry in receipts[-100:]],
            "review_events": len(contract.log) - len(receipts)}


@app.get("/antifraud/demo")
def antifraud_demo(seed: int = 0):
    if not 0 <= seed <= 10000:
        raise HTTPException(422, "Неверный seed")
    transactions, planted = make_transactions(seed=seed)
    ranked = detect(transactions, seed=seed)
    merchant_ids, feature_matrix = merchant_features(transactions)
    features_by_merchant = {
        merchant: dict(zip(FEATURES, (float(value) for value in row)))
        for merchant, row in zip(merchant_ids, feature_matrix)
    }
    # Compare each ranked merchant against *other* merchants, never against
    # the top-10 subset and never including that merchant in its baseline.
    peer_count = len(features_by_merchant) - 1
    feature_totals = {
        name: sum(row[name] for row in features_by_merchant.values())
        for name in FEATURES
    }

    def peer_comparison(merchant):
        if peer_count < 1:
            return None
        current = features_by_merchant[merchant]
        mean = lambda name: (feature_totals[name] - current[name]) / peer_count
        return {
            "merchant_count": peer_count,
            "signals": {
                "transaction_count": round(mean("n_tx"), 2),
                "student_count": round(mean("n_students"), 2),
                "largest_student_share": round(mean("top_student_share"), 4),
                "round_large_share": round(mean("round_share"), 4),
                "night_share": round(mean("night_share"), 4),
                "average_amount_rub": round(mean("mean_amount"), 2),
            },
        }

    top = [
        {"merchant": merchant,
         "comparison": peer_comparison(merchant),
         "anomaly_score": round(float(score), 4),
         "planted_anomaly": merchant in planted,
         "signals": {
             "transaction_count": int(features_by_merchant[merchant]["n_tx"]),
             "student_count": int(features_by_merchant[merchant]["n_students"]),
             "largest_student_share": round(features_by_merchant[merchant]["top_student_share"], 4),
             "round_large_share": round(features_by_merchant[merchant]["round_share"], 4),
             "night_share": round(features_by_merchant[merchant]["night_share"], 4),
             "average_amount_rub": round(features_by_merchant[merchant]["mean_amount"], 2)
         }}
        for merchant, score in ranked[:10]
    ]
    return {"mode": "synthetic", "transactions": len(transactions),
            "merchant_count": len(ranked), "planted_count": len(planted),
            "top": top,
            "score_note": "Оценка аномальности — относительный рейтинг модели, не вероятность мошенничества.",
            "signals_note": "Признаки — наблюдаемые характеристики синтетического набора, не объяснение причин решения модели.",
            "warning": "Синтетический сценарий, не показатели реального мошенничества"}


class EconomicsIn(StrictModel):
    workflows_per_year: int = Field(ge=1, le=100000000)
    manual_minutes: float = Field(gt=0, le=100000)
    automated_minutes: float = Field(ge=0, le=100000)
    hourly_cost_rub: float = Field(gt=0, le=100000000)
    maintenance_rub_year: float = Field(ge=0, le=100000000000)
    development_rub: float = Field(ge=0, le=100000000000)


@app.post("/economics/scenario")
def economics_calculator(body: EconomicsIn):
    try:
        return scenario(**body.model_dump())
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


# Pages of the research workspace. The old /demo URL remains supported.
# These are local demonstration pages: no authentication, no financial data isolation.
WEB_ROOT = Path(__file__).with_name("web")
app.mount("/app/static", StaticFiles(directory=WEB_ROOT), name="workspace-assets")
WORKSPACE_SECTIONS = {"overview", "estimates", "receipts", "history", "antifraud", "economics"}


@app.get("/app", response_class=FileResponse, include_in_schema=False)
def workspace_home():
    return FileResponse(WEB_ROOT / "index.html", media_type="text/html")


@app.get("/app/{section}", response_class=FileResponse, include_in_schema=False)
def workspace_page(section: str):
    if section not in WORKSPACE_SECTIONS:
        raise HTTPException(404, "Раздел не найден")
    return FileResponse(WEB_ROOT / "index.html", media_type="text/html")
